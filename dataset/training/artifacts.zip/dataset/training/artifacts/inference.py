"""Standalone NILM inference (weights + config bundle + architecture code in ./model).

    from inference import NILMModel, make_input
    nilm = NILMModel("nilm_pipeline.pt")                    # torch.load(weights_only=True)
    x = make_input(series)                                  # pandas Series, W, 15 s, len == nilm.window
    out = nilm.predict(x)                                   # dict of numpy arrays

Alternatively, without any model code:  torch.export.load("nilm_pipeline.pt2").module()(x)
returns (appliance_w, other_w, p_on) for x of shape (B, 9, window).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from model.GRUDetector import GRUConfig, GRUDetector  # noqa: E402
from model.NILMFormerRegressor import NILMFormerConfig, NILMFormerRegressor  # noqa: E402


def time_features(index: pd.DatetimeIndex) -> np.ndarray:
    """(8, L) sin/cos of minute, hour, weekday, month — identical to dataset/training/data.py."""
    values = []
    for value, period in ((index.minute, 60), (index.hour, 24), (index.day_of_week, 7), (index.month - 1, 12)):
        angle = 2 * np.pi * np.asarray(value, dtype=np.float64) / period
        values.extend((np.sin(angle), np.cos(angle)))
    return np.asarray(values, dtype=np.float32)


def make_input(series: pd.Series) -> np.ndarray:
    """Aggregate power (W) on a regular 15 s index, no gaps -> model input (1, 9, L)."""
    if series.isna().any():
        raise ValueError("windows must not contain gaps (NaN)")
    agg = np.clip(series.to_numpy(np.float32), 0.0, None)
    return np.concatenate([agg[None], time_features(pd.DatetimeIndex(series.index))])[None].astype(np.float32)


class NILMModel:
    def __init__(self, path: str | Path = HERE / "nilm_pipeline.pt", device: str = "cpu"):
        b = torch.load(path, map_location="cpu", weights_only=True)
        self.device = torch.device(device)
        self.appliances, self.labels = b["appliances"], b["labels"]
        self.window, self.tau_w, self.gate = int(b["window"]), float(b["tau_w"]), b["gate"]
        self.event_thresholds = torch.tensor(b["event_thresholds"], device=self.device)
        self.detectors, self.regressors, scales = [], [], []
        for m in b["members"]:
            d = GRUDetector(GRUConfig(**m["detector_config"])); d.load_state_dict(m["detector_state"])
            r = NILMFormerRegressor(NILMFormerConfig(**m["regressor_config"])); r.load_state_dict(m["regressor_state"])
            self.detectors.append(d.to(self.device).eval()); self.regressors.append(r.to(self.device).eval())
            scales.append(torch.tensor(m["scale_w"], dtype=torch.float32))
        self.scales = torch.stack(scales).to(self.device)            # (M, C)

    @torch.no_grad()
    def predict(self, x: np.ndarray | torch.Tensor) -> dict[str, np.ndarray]:
        """x: (B, 9, window) [aggregate W, 8 time features] -> W per appliance, Other, P(ON), ON events."""
        xb = torch.as_tensor(x, dtype=torch.float32, device=self.device)
        if xb.shape[1:] != (9, self.window):
            raise ValueError(f"expected (B, 9, {self.window}), got {tuple(xb.shape)}")
        agg_kw = xb[:, :1] / 1000.0
        z = torch.cat([agg_kw, torch.diff(agg_kw, dim=-1, prepend=agg_kw[..., :1]), xb[:, 1:]], dim=1)
        xr = torch.cat([xb[:, :1] / self.tau_w, xb[:, 1:]], dim=1)
        p_on = torch.stack([torch.sigmoid(d(z)) for d in self.detectors]).mean(0)
        power = torch.stack([r(xr) * s[None, :, None] for r, s in zip(self.regressors, self.scales)])
        power = power.median(0).values.clamp(min=0)
        appliance_w = p_on * power if self.gate == "soft" else power * (p_on >= self.event_thresholds[None, :, None])
        other_w = (xb[:, 0] - appliance_w.sum(1)).clamp(min=0)
        return {"appliance_w": appliance_w.cpu().numpy(), "other_w": other_w.cpu().numpy(),
                "p_on": p_on.cpu().numpy(),
                "on_event": (p_on >= self.event_thresholds[None, :, None]).cpu().numpy()}
